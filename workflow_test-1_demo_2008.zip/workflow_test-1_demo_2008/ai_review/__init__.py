"""
AI Code Review Package

A CrewAI-powered code review system for GitHub pull requests that provides
intelligent analysis and feedback on code changes.

Main Components:
- AICodeReviewCrew: Main CrewAI orchestrator
- Pydantic Models: Structured data models for code analysis
- Specialized Agents: Code analyzer and comment generator
"""

from .crew_setup import AICodeReviewCrew
from .models import (
    CodeIssue,
    CodeAnalysis,
    GitHubComment,
    ReviewSummary
)

__version__ = "1.0.0"
__author__ = "AI Code Review Team"

__all__ = [
    "AICodeReviewCrew",
    "CodeIssue",
    "CodeAnalysis", 
    "GitHubComment",
    "ReviewSummary"
]