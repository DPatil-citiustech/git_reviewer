import os
import yaml
import re
from typing import Dict, List, Optional
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, LLM
from .models import CodeAnalysis, GitHubComment, ReviewSummary, CodeIssue

load_dotenv()


class AICodeReviewCrew:
    """CrewAI-powered code review system for GitHub pull requests."""
    
    def __init__(self):
        self.azure_llm = LLM(
            model=f"azure/{os.getenv('AZURE_OPENAI_DEPLOYMENT')}",
            api_base=os.getenv("AZURE_OPENAI_ENDPOINT"),
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2023-12-01-preview")
        )
        
        # Load agent and task configurations
        self.agents_config = self._load_config("agents.yaml")
        self.tasks_config = self._load_config("tasks.yaml")
        
        # Initialize agents
        self.code_analyzer_agent = Agent(
            config=self.agents_config["code_analyzer_agent"],
            llm=self.azure_llm
        )
        
        self.comment_generator_agent = Agent(
            config=self.agents_config["comment_generator_agent"],
            llm=self.azure_llm
        )
    
    def _load_config(self, filename: str) -> Dict:
        """Load YAML configuration file."""
        config_path = os.path.join(os.path.dirname(__file__), "config", filename)
        with open(config_path, "r") as f:
            return yaml.safe_load(f)
    
    def _get_changed_lines(self, patch: str) -> List[int]:
        """Extract line numbers that were added or modified from the patch."""
        changed_lines = []
        if not patch:
            return changed_lines
            
        current_line = 0
        for line in patch.split('\n'):
            if line.startswith('@@'):
                # Parse hunk header: @@ -old_start,old_count +new_start,new_count @@
                match = re.search(r'\+(\d+)', line)
                if match:
                    current_line = int(match.group(1)) - 1
            elif line.startswith('+') and not line.startswith('+++'):
                # This is an added line
                current_line += 1
                changed_lines.append(current_line)
            elif line.startswith(' '):
                # Context line
                current_line += 1
                
        return changed_lines
    
    def review_file(self, file_data: Dict, pr_data: Dict) -> Optional[CodeAnalysis]:
        """Review a single file using the AI crew."""
        try:
            # Create analysis task
            analyze_task = Task(
                config=self.tasks_config["analyze_code_task"],
                agent=self.code_analyzer_agent,
                output_pydantic=CodeAnalysis
            )
            
            # Format task inputs
            task_inputs = {
                "filename": file_data["filename"],
                "file_status": file_data["status"],
                "changes": file_data["changes"],
                "additions": file_data["additions"],
                "deletions": file_data["deletions"],
                "patch": file_data.get("patch", ""),
                "file_content": file_data.get("content", ""),
                "pr_title": pr_data["title"],
                "pr_description": pr_data.get("body", "No description provided")
            }
            
            # Create and run crew for analysis
            analysis_crew = Crew(
                agents=[self.code_analyzer_agent],
                tasks=[analyze_task],
                verbose=True
            )
            
            result = analysis_crew.kickoff(inputs=task_inputs)
            
            # Return the Pydantic model result
            if hasattr(result, 'pydantic') and result.pydantic:
                return result.pydantic
            else:
                # Fallback parsing if needed
                return self._parse_analysis_result(result, file_data["filename"])
                
        except Exception as e:
            print(f"Error analyzing file {file_data['filename']}: {str(e)}")
            return None
    
    def generate_github_comments(self, analysis: CodeAnalysis, changed_lines: List[int]) -> List[GitHubComment]:
        """Generate GitHub-ready comments from analysis results."""
        try:
            # Create comment generation task
            comment_task = Task(
                config=self.tasks_config["generate_comments_task"],
                agent=self.comment_generator_agent,
                output_pydantic=ReviewSummary
            )
            
            # Format task inputs
            task_inputs = {
                "code_analysis": analysis.model_dump_json(),
                "filename": analysis.filename,
                "changed_lines": changed_lines
            }
            
            # Create and run crew for comment generation
            comment_crew = Crew(
                agents=[self.comment_generator_agent],
                tasks=[comment_task],
                verbose=True
            )
            
            result = comment_crew.kickoff(inputs=task_inputs)
            
            # Return the GitHub comments from the result
            if hasattr(result, 'pydantic') and result.pydantic:
                return result.pydantic.github_comments
            else:
                # Fallback comment generation
                return self._generate_fallback_comments(analysis, changed_lines)
                
        except Exception as e:
            print(f"Error generating comments for {analysis.filename}: {str(e)}")
            return self._generate_fallback_comments(analysis, changed_lines)
    
    def _parse_analysis_result(self, result, filename: str) -> CodeAnalysis:
        """Fallback method to parse analysis result if Pydantic parsing fails."""
        try:
            # Try to extract structured data from result
            if hasattr(result, 'raw'):
                content = result.raw
            else:
                content = str(result)
            
            # Basic parsing logic here - you might need to adapt based on actual output format
            return CodeAnalysis(
                filename=filename,
                issues=[],  # Parse issues from content
                summary=f"Analysis completed for {filename}"
            )
        except Exception:
            return CodeAnalysis(
                filename=filename,
                issues=[],
                summary=f"Failed to parse analysis for {filename}"
            )
    
    def _generate_fallback_comments(self, analysis: CodeAnalysis, changed_lines: List[int]) -> List[GitHubComment]:
        """Enhanced fallback method to generate comments with suggestions."""
        comments = []
        
        for issue in analysis.issues:
            # FIXED: Use case-insensitive comparison for severity
            severity_lower = issue.severity.lower()
            if severity_lower in ['high', 'medium'] and issue.line in changed_lines:
                severity_label = "**HIGH**" if severity_lower == "high" else "**MEDIUM**"
                
                # Try to generate a simple suggestion for common issues
                suggestion_block = self._generate_suggestion_block(issue, analysis.filename)
                
                body = f"{severity_label} - {issue.category.upper()}\n\n{issue.message}\n\n**Suggestion:**\n{issue.suggestion}"
                
                if suggestion_block:
                    body += f"\n\n{suggestion_block}"
                
                comments.append(GitHubComment(
                    path=analysis.filename,
                    line=issue.line,
                    body=body
                ))
        
        return comments
    
    def _generate_suggestion_block(self, issue: CodeIssue, filename: str) -> str:
        """Generate a GitHub suggestion block for simple fixes."""
        # Only generate suggestions for simple, clear fixes
        suggestion_patterns = {
            'typo': r'(typo|misspell|incorrect.*name)',
            'syntax': r'(syntax.*error|missing.*parenthes|incomplete.*call)',
            'simple_fix': r'(replace.*with|change.*to|fix.*by)'
        }
        
        message_lower = issue.message.lower()
        suggestion_lower = issue.suggestion.lower()
        
        # Check if this looks like a simple fix
        is_simple_fix = any(
            re.search(pattern, message_lower) or re.search(pattern, suggestion_lower)
            for pattern in suggestion_patterns.values()
        )
        
        if is_simple_fix and 'replace' in suggestion_lower:
            # Try to extract the suggested replacement
            # This is a basic implementation - the AI should handle this better
            return "```suggestion\n# Please apply the suggested fix from above\n```"
        
        return ""
    
    def create_review_summary(self, all_analyses: List[CodeAnalysis], all_comments: List[GitHubComment]) -> str:
        """Create a comprehensive review summary with FIXED case-insensitive severity counting."""
        total_files = len(all_analyses)
        total_issues = sum(len(analysis.issues) for analysis in all_analyses)
        
        # FIXED: Count by severity with case-insensitive comparison
        severity_counts = {"high": 0, "medium": 0, "low": 0}
        for analysis in all_analyses:
            for issue in analysis.issues:
                # Convert to lowercase for consistent comparison
                severity_lower = issue.severity.lower()
                if severity_lower in severity_counts:
                    severity_counts[severity_lower] += 1
        
        summary = f"""## AI Code Review Summary

**Files Reviewed:** {total_files}
**Total Issues Found:** {total_issues}
**Comments Posted:** {len(all_comments)}

### Issue Breakdown:
- **High Severity:** {severity_counts['high']} issues
- **Medium Severity:** {severity_counts['medium']} issues  
- **Low Severity:** {severity_counts['low']} issues

### Files Analyzed:
{chr(10).join(f"- `{analysis.filename}`: {len(analysis.issues)} issues" for analysis in all_analyses)}

---
*This review was generated by AI. Please use human judgment for final decisions.*
"""
        
        return summary