from typing import List, Optional
from pydantic import BaseModel, Field


class CodeIssue(BaseModel):
    """Represents a single code issue found during analysis."""
    line: int = Field(..., description="Line number where the issue occurs")
    severity: str = Field(..., description="Severity level: high, medium, or low")
    category: str = Field(..., description="Issue category: security, performance, bug, or quality")
    message: str = Field(..., description="Description of the issue")
    suggestion: str = Field(..., description="Suggested fix or improvement")


class CodeAnalysis(BaseModel):
    """Results from analyzing a single file."""
    filename: str = Field(..., description="Name of the analyzed file")
    issues: List[CodeIssue] = Field(default_factory=list, description="List of issues found in the file")
    summary: str = Field(..., description="Brief summary of the analysis")


class GitHubComment(BaseModel):
    """Formatted comment ready for GitHub API."""
    path: str = Field(..., description="File path for the comment")
    line: Optional[int] = Field(None, description="Line number for inline comments")
    body: str = Field(..., description="Comment body in markdown format")
    side: str = Field(default="RIGHT", description="Which side of the diff to comment on")


class ReviewSummary(BaseModel):
    """Complete review summary for the pull request."""
    total_files_reviewed: int = Field(..., description="Number of files analyzed")
    total_issues_found: int = Field(..., description="Total number of issues found")
    high_severity_count: int = Field(default=0, description="Number of high severity issues")
    medium_severity_count: int = Field(default=0, description="Number of medium severity issues")
    low_severity_count: int = Field(default=0, description="Number of low severity issues")
    github_comments: List[GitHubComment] = Field(default_factory=list, description="Formatted GitHub comments")
    summary_text: str = Field(..., description="Overall review summary in markdown")