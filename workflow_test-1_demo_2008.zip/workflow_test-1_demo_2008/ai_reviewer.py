#!/usr/bin/env python3

import os
import re
import base64
import sys
from typing import List, Dict
from github import Github
from dotenv import load_dotenv
from ai_review.crew_setup import AICodeReviewCrew

load_dotenv()


class GitHubAIReviewer:
    """Main GitHub AI code reviewer using CrewAI."""
    
    def __init__(self):
        self.github_token = os.getenv('GITHUB_TOKEN')
        
        if not self.github_token:
            raise ValueError("GITHUB_TOKEN environment variable is required")
        
        self.github = Github(self.github_token)
        
        # Initialize CrewAI reviewer
        self.ai_crew = AICodeReviewCrew()
        
        # GitHub PR details
        self.owner = os.getenv('REPO_OWNER')
        self.repo_name = os.getenv('REPO_NAME')
        self.pr_number = int(os.getenv('PR_NUMBER'))
        self.base_sha = os.getenv('BASE_SHA')
        self.head_sha = os.getenv('HEAD_SHA')
        
        self.repo = self.github.get_repo(f"{self.owner}/{self.repo_name}")
        self.pr = self.repo.get_pull(self.pr_number)
        
        # CONFIGURABLE: Set blocking severity level
        # Options: 'high' (block only on high), 'medium' (block on medium+high), 'none' (never block)
        self.block_severity_level = os.getenv('BLOCK_SEVERITY_LEVEL', 'high').lower()

    def should_review_file(self, filename: str) -> bool:
        """Determine if a file should be reviewed based on its extension and path."""
        exclude_patterns = [
            r'\.md$', r'\.txt$', r'\.json$', r'package-lock\.json$',
            r'yarn\.lock$', r'\.min\.js$', r'\.map$', r'/dist/',
            r'/build/', r'/node_modules/', r'__pycache__', r'\.pyc$',
            r'\.gitignore$', r'\.env', r'\.yaml$', r'\.yml$'
        ]
        
        include_patterns = [
            r'\.(js|jsx|ts|tsx|py|java|cpp|c|h|cs|php|rb|go|rs|swift|kt|scala)$'
        ]
        
        # Check exclude patterns
        for pattern in exclude_patterns:
            if re.search(pattern, filename, re.IGNORECASE):
                return False
        
        # Check include patterns
        for pattern in include_patterns:
            if re.search(pattern, filename, re.IGNORECASE):
                return True
        
        return False

    def get_file_content(self, filename: str) -> str:
        """Get the content of a file from the repository."""
        try:
            content = self.repo.get_contents(filename, ref=self.head_sha)
            if content.content:
                return base64.b64decode(content.content).decode('utf-8')
            return ""
        except Exception as e:
            print(f"Could not fetch content for {filename}: {str(e)}")
            return ""

    def prepare_file_data(self, github_file) -> Dict:
        """Prepare file data for AI analysis."""
        file_content = self.get_file_content(github_file.filename)
        
        return {
            'filename': github_file.filename,
            'status': github_file.status,
            'changes': github_file.changes,
            'additions': github_file.additions,
            'deletions': github_file.deletions,
            'patch': getattr(github_file, 'patch', ''),
            'content': file_content
        }

    def prepare_pr_data(self) -> Dict:
        """Prepare PR data for context."""
        return {
            'title': self.pr.title,
            'body': self.pr.body,
            'number': self.pr.number,
            'base_ref': self.pr.base.ref,
            'head_ref': self.pr.head.ref
        }

    def get_line_mapping_from_patch(self, patch: str) -> Dict[int, int]:
        """
        Create mapping from new file line numbers to diff line positions.
        This is crucial for proper inline comment placement.
        """
        line_mapping = {}  # new_line_number -> diff_position
        
        if not patch:
            return line_mapping
        
        diff_lines = patch.split('\n')
        current_new_line = 0
        diff_position = 0
        
        for line in diff_lines:
            diff_position += 1
            
            if line.startswith('@@'):
                # Parse hunk header: @@ -old_start,old_count +new_start,new_count @@
                match = re.search(r'\+(\d+)', line)
                if match:
                    current_new_line = int(match.group(1)) - 1
            elif line.startswith('+') and not line.startswith('+++'):
                # This is an added line
                current_new_line += 1
                line_mapping[current_new_line] = diff_position
            elif line.startswith(' '):
                # Context line - exists in both old and new
                current_new_line += 1
                line_mapping[current_new_line] = diff_position
            # Lines starting with '-' don't increment new line counter
                
        print(f"[DEBUG] Line mapping created: {line_mapping}")
        return line_mapping

    def count_severity_issues(self, all_analyses) -> Dict[str, int]:
        """Count issues by severity level."""
        severity_counts = {"high": 0, "medium": 0, "low": 0}
        
        print(f"[DEBUG] count_severity_issues called with {len(all_analyses)} analyses")
        
        for i, analysis in enumerate(all_analyses):
            print(f"[DEBUG] Processing analysis {i}: {analysis.filename}")
            print(f"[DEBUG] Analysis has {len(analysis.issues)} issues")
            
            for j, issue in enumerate(analysis.issues):
                # Convert severity to lowercase for consistent comparison
                severity_lower = issue.severity.lower()
                print(f"[DEBUG] Issue {j}: severity='{issue.severity}' -> '{severity_lower}', line={issue.line}")
                
                if severity_lower in severity_counts:
                    severity_counts[severity_lower] += 1
                    print(f"[DEBUG] Incremented {severity_lower} count to {severity_counts[severity_lower]}")
                else:
                    print(f"[DEBUG] Unknown severity: '{severity_lower}'")
        
        print(f"[DEBUG] Final severity counts: {severity_counts}")
        return severity_counts

    def determine_review_status(self, severity_counts: Dict[str, int]) -> tuple:
        """
        Determine if review should pass or fail based on severity counts and configuration.
        Returns: (should_block: bool, status_description: str, review_event: str)
        """
        high_count = severity_counts.get('high', 0)
        medium_count = severity_counts.get('medium', 0)
        low_count = severity_counts.get('low', 0)
        total_issues = high_count + medium_count + low_count
        
        if self.block_severity_level == 'none':
            # Never block, just comment
            if total_issues == 0:
                return False, "PASS: No issues found", "COMMENT"
            else:
                return False, f"INFO: Found {total_issues} issues (non-blocking mode)", "COMMENT"
        
        elif self.block_severity_level == 'high':
            # Block only on high severity
            if high_count > 0:
                return True, f"FAIL: BLOCKING - {high_count} high severity issues found", "REQUEST_CHANGES"
            elif medium_count > 0:
                return False, f"WARNING: {medium_count} medium severity issues (non-blocking)", "COMMENT"
            elif low_count > 0:
                return False, f"INFO: {low_count} low severity issues found", "COMMENT"
            else:
                return False, "PASS: No issues found", "COMMENT"
        
        elif self.block_severity_level == 'medium':
            # Block on medium and high severity
            if high_count > 0:
                return True, f"FAIL: BLOCKING - {high_count} high severity issues found", "REQUEST_CHANGES"
            elif medium_count > 0:
                return True, f"FAIL: BLOCKING - {medium_count} medium severity issues found", "REQUEST_CHANGES"
            elif low_count > 0:
                return False, f"INFO: {low_count} low severity issues found", "COMMENT"
            else:
                return False, "PASS: No issues found", "COMMENT"
        
        else:
            # Default to high-only blocking
            return self.determine_review_status(severity_counts) if self.block_severity_level != 'high' else (False, "WARNING: Invalid configuration", "COMMENT")

    def create_status_summary(self, all_analyses, severity_counts: Dict[str, int], files_reviewed: int) -> str:
        """Create a detailed status summary for the check description."""
        high_count = severity_counts.get('high', 0)
        medium_count = severity_counts.get('medium', 0)
        low_count = severity_counts.get('low', 0)
        total_issues = high_count + medium_count + low_count
        
        summary_parts = [
            f"FILES: {files_reviewed}",
            f"ISSUES: {total_issues}",
        ]
        
        if high_count > 0:
            summary_parts.append(f"HIGH: {high_count}")
        if medium_count > 0:
            summary_parts.append(f"MEDIUM: {medium_count}")
        if low_count > 0:
            summary_parts.append(f"LOW: {low_count}")
        
        if total_issues == 0:
            summary_parts.append("STATUS: Clean code, no issues found!")
        
        summary_parts.append(f"BLOCK_LEVEL: {self.block_severity_level}")
        
        return " | ".join(summary_parts)

    def submit_review(self, all_comments: List, summary: str, review_event: str = "COMMENT") -> None:
        """Submit the AI review to GitHub with proper inline comment placement."""
        if not all_comments:
            print("No comments to submit")
            return

        try:
            # Better handling of line comments with proper positioning
            review_comments = []
            general_comments = []
            
            for comment in all_comments:
                if hasattr(comment, 'line') and comment.line and hasattr(comment, 'path'):
                    # This should be an inline comment
                    review_comments.append({
                        'path': comment.path,
                        'line': comment.line,
                        'body': comment.body
                    })
                    print(f"[DEBUG] Adding inline comment: {comment.path}:{comment.line}")
                else:
                    # General comment
                    general_comments.append(comment.body)
            
            if review_comments:
                # Submit review with inline comments
                print(f"[INFO] Submitting {len(review_comments)} inline comments with event: {review_event}")
                
                self.pr.create_review(
                    body=summary,
                    event=review_event,
                    comments=review_comments
                )
                print(f"[SUCCESS] Submitted {review_event.lower()} review with {len(review_comments)} inline comments")
                
            else:
                # No inline comments, just submit summary
                self.pr.create_review(
                    body=summary,
                    event=review_event
                )
                print(f"[SUCCESS] Submitted {review_event.lower()} review (summary only)")
                
            # Post any general comments separately
            for comment_body in general_comments:
                self.pr.create_issue_comment(comment_body)
                
        except Exception as e:
            print(f"[ERROR] Error submitting review: {str(e)}")
            print(f"[DEBUG] Review comments attempted: {review_comments}")
            
            # Enhanced: Better fallback with individual review comments
            self._submit_fallback_comments(all_comments, summary)

    def _submit_fallback_comments(self, all_comments: List, summary: str) -> None:
        """Enhanced: Fallback method with better error handling."""
        print("[INFO] Attempting fallback comment submission...")
        
        # Post summary as a general comment
        try:
            self.pr.create_issue_comment(summary)
            print("[SUCCESS] Posted review summary")
        except Exception as e:
            print(f"[ERROR] Failed to post summary: {str(e)}")
        
        # Try to post individual review comments (these attach to specific lines)
        for comment in all_comments:
            if hasattr(comment, 'line') and comment.line and hasattr(comment, 'path'):
                try:
                    # Try review comment first (inline)
                    self.pr.create_review_comment(
                        body=comment.body,
                        commit=self.pr.head.sha,
                        path=comment.path,
                        line=comment.line
                    )
                    print(f"[SUCCESS] Posted inline comment on {comment.path}:{comment.line}")
                except Exception as e:
                    print(f"[ERROR] Failed inline comment on {comment.path}:{comment.line}: {str(e)}")
                    # Last resort: post as general comment with context
                    try:
                        contextualized_body = f"**{comment.path} (Line {comment.line})**\n\n{comment.body}"
                        self.pr.create_issue_comment(contextualized_body)
                        print(f"[SUCCESS] Posted contextualized comment for {comment.path}:{comment.line}")
                    except Exception as e2:
                        print(f"[ERROR] Failed contextualized comment: {str(e2)}")

    def review_pull_request(self) -> None:
        """Main method to review the entire pull request using AI crew."""
        try:
            print(f"[START] Starting AI crew review for PR #{self.pr_number}")
            print(f"[CONFIG] Block severity level: {self.block_severity_level}")
            
            # Get changed files
            files = list(self.pr.get_files())
            
            if not files:
                print("[INFO] No files to review")
                return
            
            # Filter files to review
            files_to_review = []
            for file in files:
                if self.should_review_file(file.filename):
                    files_to_review.append(file)
                else:
                    print(f"[SKIP] Skipping {file.filename} (excluded file type)")
            
            if not files_to_review:
                print("[INFO] No relevant files to review after filtering")
                return
            
            print(f"[INFO] Reviewing {len(files_to_review)} files with AI crew...")
            
            # Prepare PR context
            pr_data = self.prepare_pr_data()
            
            # Review each file using AI crew
            all_analyses = []
            all_comments = []
            
            for file in files_to_review:
                print(f"[ANALYZE] Analyzing {file.filename}...")
                
                # Prepare file data
                file_data = self.prepare_file_data(file)
                
                # Get changed lines for validation
                changed_lines = self.ai_crew._get_changed_lines(file_data.get('patch', ''))
                
                # Get line mapping for proper comment placement
                line_mapping = self.get_line_mapping_from_patch(file_data.get('patch', ''))
                
                # Analyze file with AI crew
                analysis = self.ai_crew.review_file(file_data, pr_data)
                
                if analysis and analysis.issues:
                    # ALWAYS add analysis to the list if it has issues, regardless of comment validation
                    all_analyses.append(analysis)
                    
                    # Generate GitHub comments
                    comments = self.ai_crew.generate_github_comments(analysis, changed_lines)
                    
                    # Ensure comments have proper line numbers that exist in the diff
                    validated_comments = []
                    for comment in comments:
                        if hasattr(comment, 'line') and comment.line:
                            # Validate that this line exists in the changed lines (with tolerance for off-by-one)
                            if comment.line in changed_lines or comment.line in line_mapping or abs(comment.line - max(changed_lines, default=0)) <= 1:
                                validated_comments.append(comment)
                                print(f"[DEBUG] Validated comment at line {comment.line}")
                            else:
                                print(f"[WARNING] Adjusting comment from line {comment.line} to nearest changed line")
                                # Try to map to the nearest changed line
                                if changed_lines:
                                    nearest_line = min(changed_lines, key=lambda x: abs(x - comment.line))
                                    adjusted_comment = type(comment)(
                                        path=comment.path,
                                        line=nearest_line,
                                        body=f"**Near Line {comment.line}**: {comment.body}"
                                    )
                                    validated_comments.append(adjusted_comment)
                                    print(f"[DEBUG] Adjusted comment to line {nearest_line}")
                                else:
                                    # Convert to general comment with context
                                    contextualized_comment = type(comment)(
                                        path=comment.path,
                                        line=None,  # Remove line to make it a general comment
                                        body=f"**Line {comment.line}**: {comment.body}"
                                    )
                                    validated_comments.append(contextualized_comment)
                                    print(f"[DEBUG] Converted to general comment")
                        else:
                            validated_comments.append(comment)
                    
                    all_comments.extend(validated_comments)
                    
                    print(f"[RESULT] Found {len(analysis.issues)} issues, generated {len(validated_comments)} comments")
                else:
                    print(f"[CLEAN] No issues found in {file.filename}")
            
            # Count severity issues and determine status
            severity_counts = self.count_severity_issues(all_analyses)
            should_block, status_description, review_event = self.determine_review_status(severity_counts)
            
            # DEBUG: Print severity counts to debug the issue
            print(f"[DEBUG] Severity counts: {severity_counts}")
            print(f"[DEBUG] Should block: {should_block}")
            print(f"[DEBUG] Total analyses: {len(all_analyses)}")
            for i, analysis in enumerate(all_analyses):
                print(f"[DEBUG] Analysis {i}: {analysis.filename} has {len(analysis.issues)} issues")
                for j, issue in enumerate(analysis.issues):
                    print(f"[DEBUG]   Issue {j}: Line {issue.line}, Severity: {issue.severity}")
            
            # Create status summary for GitHub check
            status_summary = self.create_status_summary(all_analyses, severity_counts, len(files_to_review))
            
            # Determine which path to take based on whether we have issues to report
            has_issues_to_report = len(all_comments) > 0 or sum(severity_counts.values()) > 0
            
            # Create and submit review
            if has_issues_to_report:
                summary = self.ai_crew.create_review_summary(all_analyses, all_comments)
                
                # Add status information to summary
                enhanced_summary = f"{status_description}\n\n{status_summary}\n\n---\n{summary}"
                
                self.submit_review(all_comments, enhanced_summary, review_event)
                
                # Print final status
                print(f"[STATUS] {status_description}")
                print(f"[SUMMARY] {status_summary}")
                
                # Exit with appropriate code based on blocking decision
                if should_block:
                    print(f"[BLOCKING] Exiting with error code due to {self.block_severity_level} severity issues")
                    sys.exit(1)
                else:
                    print(f"[COMPLETE] Review completed successfully")
                    sys.exit(0)
            else:
                # Handle case where we have analyses but no issues, OR no analyses at all
                if all_analyses:
                    # We have analyses but no issues
                    summary = "AI Code Review Completed - No issues found in any files - excellent work!"
                    status_summary = self.create_status_summary(all_analyses, {"high": 0, "medium": 0, "low": 0}, len(files_to_review))
                else:
                    # No analyses at all
                    summary = "AI Code Review Completed - No files were analyzed"
                    status_summary = f"FILES: {len(files_to_review)} | ISSUES: 0 | STATUS: No files analyzed | BLOCK_LEVEL: {self.block_severity_level}"
                
                enhanced_summary = f"PASS: No issues found\n\n{status_summary}\n\n---\n{summary}"
                
                self.pr.create_review(body=enhanced_summary, event="COMMENT")
                print("[COMPLETE] No issues found in any files - great code!")
                sys.exit(0)
                
        except Exception as e:
            print(f"[FATAL] Error during AI crew review: {str(e)}")
            # Exit with error on fatal errors
            sys.exit(1)


def main():
    """Main entry point."""
    try:
        reviewer = GitHubAIReviewer()
        reviewer.review_pull_request()
    except Exception as e:
        print(f"[FATAL] Fatal error: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()